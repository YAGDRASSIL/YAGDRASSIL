# кругляем дробное число до сотых

import math

print("Ввведите ваше число:")

i = float(input())

x = round(i , 2)

print("Получаеться число: ", x)