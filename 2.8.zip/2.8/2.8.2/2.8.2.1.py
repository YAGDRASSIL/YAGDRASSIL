# расчёт чётного числа 

print("Введите n:")
n = int(input())

n = n *2 

print(n)